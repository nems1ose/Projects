function inverse(arr, n) {
    if (n === undefined || n == 0) {
        return arr.reverse();
    }
    if (n > 0) {
        let m = -arr.length + n;
        let lastThree = (arr.splice(m)).reverse();
        return arr.concat(lastThree);
    }
    else{
        let m = arr.length + n;
        let firstThree = (arr.splice(m));
        return (arr).reverse().concat(firstThree);
    }
}

console.log(inverse([1, 2, 3, 4, 5], -5));          // [1, 2, 3, 4, 5]
console.log(inverse([1, 2, 3, 4, 5], -2));          // [3, 2, 1, 4, 5]
console.log(inverse([1, 2, 3, 4, 5]));              // [5, 4, 3, 2, 1]
console.log(inverse([1, 2, 3, 4, 5], 0));           // [5, 4, 3, 2, 1]
console.log(inverse([1, 2, 3, 4, 5], 2));           // [1, 2, 5, 4, 3]
console.log(inverse([1, 2, 3, 4, 5], 5));           // [1, 2, 3, 4, 5]