import {ProductCardComponent} from "../../components/product-card/index.js";


export class MainPage {
    constructor(parent) {
        this.parent = parent;
    }
    getData() {
        return [
            {
                id: 1,
                src: "https://super.ru/image/rs::3840:::/quality:90/plain/s3:/super-static/prod/62b582de093f961f612e6e48-1900x.jpeg",
                title: "<b>Рэгдолл</b>",
                text: "500 рублей",
            },
            {
                id: 2,
                src: "https://pichold.ru/wp-content/uploads/2018/11/britanskaya_korotkosherstnaya_koshka_13.jpg",
                title: "<b>Британец</b>",
                text: "550 рублей",
            },
            {
                id: 3,
                src: "https://w.forfun.com/fetch/e3/e3d1b2b9eab9873731c701f345a3c0dd.jpeg?w=1800",
                title: "<b>Абиссинцы</b>",
                text: "750 рублей",
            },
        ]
    }
        
    render() {
        this.parent.innerHTML = ''
        const html = this.getHTML()
        this.parent.insertAdjacentHTML('beforeend', html)
        
        const data = this.getData()
        data.forEach((item) => {
            const productCard = new ProductCardComponent(this.pageRoot)
            productCard.render(item, this.clickCard.bind(this))
        })
    }

    get pageRoot() {
        return document.getElementById('main-page')
    }
        
    getHTML() {
        return (
            `
                <div id="main-page" class="d-flex flex-wrap"><div/>
            `
        )
    }

    clickCard(e) {
        const cardId = e.target.dataset.id
        
        let message;
        switch (cardId) {
            case '1':
                message = '<H3>Рэгдолл</H3>Порода крупных полудлинношёрстных кошек. <a href="https://ru.wikipedia.org/wiki/%D0%A0%D1%8D%D0%B3%D0%B4%D0%BE%D0%BB%D0%BB" class="alert-link">Подробнее</a>';
                break;
            case '2':
                message = '<H3>Британец</H3>Порода домашней кошки. По одной версии является потомком породы Шартрез, а по другой, римских кошек и местных сородичей. <a href="https://ru.wikipedia.org/wiki/%D0%91%D1%80%D0%B8%D1%82%D0%B0%D0%BD%D1%81%D0%BA%D0%B0%D1%8F_%D0%BA%D0%BE%D1%80%D0%BE%D1%82%D0%BA%D0%BE%D1%88%D1%91%D1%80%D1%81%D1%82%D0%BD%D0%B0%D1%8F_%D0%BA%D0%BE%D1%88%D0%BA%D0%B0" class="alert-link">Подробнее</a>';
                break;
            case '3':
                message = '<H3>Абиссинцы</H3>Короткошёрстные кошки средних размеров. По одной из версий, порода родом из Африки (Эфиопии, государства в Северо-Восточной Африке). <a href="https://ru.wikipedia.org/wiki/%D0%90%D0%B1%D0%B8%D1%81%D1%81%D0%B8%D0%BD%D1%81%D0%BA%D0%B0%D1%8F_%D0%BA%D0%BE%D1%88%D0%BA%D0%B0" class="alert-link">Подробнее</a>';
        }
        
        const notification = document.createElement('div');
        notification.classList.add('alert', 'alert-primary');
        notification.role = 'alert';
        notification.innerHTML = message;
        document.body.appendChild(notification);
    
        setTimeout(() => {notification.remove();}, 2000);
    }
}
