export const groupId = '225093453'
export const accessToken = 'vk1.a.uAZHdchVXo-Hy3lq9jptMpey9RN9r1FUMVDhkmEpE_99dluZuOg9lzH7Qtd0uOz9q-5Lo_-xKdUGPS2W8v57jJHkFwpLyVJAIpbdUjA8XUYghOrpny_1ABr23SdHYj52iKJ6nP6MdfZZMEUhb6aIm3JQsJY-kfumQKey4wg9JdY9wgemekXe7B-GTMh-Ic3jhnJiRE9IqvPNpWI2LoWYDA'
export const version = '5.199'