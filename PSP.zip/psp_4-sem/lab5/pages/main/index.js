import {ProductCardComponent} from "../../components/product-card/index.js";
import {urls} from "../../modules/urls.js";
import {groupId} from "../../modules/consts.js";
import { ProductPage } from "../product/index.js";


export class MainPage {
    constructor(parent) {
        this.parent = parent;
    }

    getData() {
        fetch(urls.getGroupMembers(groupId))
            .then(response => response.json())
            .then(data => this.renderData(data.response.items))
            .catch(error => console.error('Error:', error));
    }

    get pageRoot() {
        return document.getElementById('main-page');
    }
        
    renderData(items) {
        items.forEach((item) => {
            const productCard = new ProductCardComponent(this.pageRoot);
            productCard.render(item, this.clickCard.bind(this));
        });
    }

    getHTML() {
        return `
            <div id="main-page" class="d-flex flex-wrap"></div>
        `;
    }

    clickCard(e) {
        const cardId = e.target.dataset.id;
        console.log("pressed ", cardId);

        const productPage = new ProductPage(this.parent, cardId);
        productPage.render();
    }

    render() {
        this.parent.innerHTML = '';
        const html = this.getHTML();
        this.parent.insertAdjacentHTML('beforeend', html);

        this.getData();
    }   
}
