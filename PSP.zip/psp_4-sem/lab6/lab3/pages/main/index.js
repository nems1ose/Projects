import {ProductCardComponent} from "../../components/product-card/index.js";
import {ProductPage} from "../product/index.js";

export class MainPage {
    constructor(parent) {
        this.parent = parent;
    }

    get pageRoot() {
        return document.getElementById('main-page')
    }
        
    getHTML = () => `
        <div id="main-page" class="d-flex flex-wrap"></div>
    `;
        
  getData = () => [
    {
        id1: 1,
        src1: "https://www.pixelstalk.net/wp-content/uploads/images6/Math-Wallpaper-HD-Free-download.png",
        title1: "Математика",

        id2: 2,
        src2: "https://wallpaper.dog/large/10978348.jpg",
        title2: "История",

        id3: 3,
        src3: "https://images.wallpaperscraft.com/image/single/abstraction_communications_physics_76297_1920x1080.jpg",
        title3: "Физика",
    },
];
  
render = () => {
    this.parent.innerHTML = '';
    const html = this.getHTML();
    this.parent.insertAdjacentHTML('beforeend', html);

    const data = this.getData();
    const productCard = new ProductCardComponent(this.pageRoot);
    productCard.render(data[0], this.clickCard);
};
    
    
clickCard = (e) => {
    const cardId = e.currentTarget.dataset.id;
    const data = this.getData();
    
    // Найдем данные для соответствующего слайда
    const selectedItem = data.find(item => item.id1 === parseInt(cardId) || item.id2 === parseInt(cardId) || item.id3 === parseInt(cardId));

    // Создадим ProductPage, передав правильный id
    const productPage = new ProductPage(this.parent, cardId);
    productPage.render();
};



}