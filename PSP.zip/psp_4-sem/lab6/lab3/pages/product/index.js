import {BackButtonComponent} from "../../components/back-button/index.js";
import {MainPage} from "../main/index.js";
import {ProductComponent} from "../../components/product/index.js";

export class ProductPage {
    constructor(parent, id) {
        this.parent = parent
        this.id = id
    }

    getData() {
        return [
        {
            src: "https://www.pixelstalk.net/wp-content/uploads/images6/Math-Wallpaper-HD-Free-download.png",
            title: `Матемтика`,
            text: "- это наука о количестве, структуре, пространстве и изменениях."
        },
        {
            src: "https://wallpaper.dog/large/10978348.jpg",
            title: `История`,
            text: "- это наука, изучающая прошлое человечества."
        },
        {
            src: "https://images.wallpaperscraft.com/image/single/abstraction_communications_physics_76297_1920x1080.jpg",
            title: `Физика`,
            text: "- это естественная наука, изучающая природу и ее законы."
        },
    
    ]
    }

    get pageRoot() {
        return document.getElementById('product-page')
    }

    getHTML() {
        return (
            `
                <div id="product-page"></div>
            `
        )
    }

    clickBack() {
        const mainPage = new MainPage(this.parent)
        mainPage.render()
    }
    
    render() {
        this.parent.innerHTML = ''
        const html = this.getHTML()
        this.parent.insertAdjacentHTML('beforeend', html)
    
        const backButton = new BackButtonComponent(this.pageRoot)
        backButton.render(this.clickBack.bind(this))
    
        const data = this.getData()
        const stock = new ProductComponent(this.pageRoot)
        stock.render(data[this.id-1])
    }
}